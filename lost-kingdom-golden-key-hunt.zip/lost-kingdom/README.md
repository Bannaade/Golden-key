# Lost Kingdom: The Golden Key Hunt

A visual 3D browser-game prototype with a fantasy kingdom, ruins, glowing caves, waterfall, exploration HUD, named seeker roster, generated room code, and invite-link UI.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder, run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Free hosting
Use a free Node.js web-service host that supports long-lived WebSocket connections (for example, Render's free web service if currently available for your account):
- Create a new web service from this repository.
- Build command: `npm install`
- Start command: `npm start`
- No environment variables are required; the host supplies `PORT`.
- Use the deployed HTTPS URL to invite friends.

## Important prototype limitations
- The current `public/index.html` is a playable visual prototype and its client-side room link is a demo. It does **not yet connect the 3D client to the Socket.IO server**; the included server is a starter for room/player state, not a completed multiplayer integration.
- The roster currently shows the five fixed names and sample exploration percentages locally. A production build must connect the client to `joinRoom`, `move`, `state`, `dig`, and `winner` Socket.IO events, reconcile movement, and handle reconnection.
- The first person to dig within the server's key radius wins, but the prototype's visual key location is currently client-generated. Production should send the authoritative key position (or a safe distance-band response) from the server.
- For public rooms, add room expiry, rate limiting, input validation, abuse protection, and a maximum of five unique player identities per room.
- Three.js is loaded from jsDelivr and fonts from Google Fonts, so those services must be reachable. Graphics are stylized real-time 3D rather than Unreal Engine photorealism.
