const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');
const path = require('path');
const app = express(), server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_, res) => res.json({ ok: true, game: 'Lost Kingdom' }));
const NAMES = ['Tom','Josh','Dave','Joe','Stone'];
const rooms = new Map();
function code(){ return crypto.randomBytes(3).toString('hex').toUpperCase(); }
io.on('connection', socket => {
 socket.on('joinRoom', ({room, name}, reply=()=>{}) => {
  room = String(room||code()).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8);
  if(!NAMES.includes(name)) return reply({error:'Choose one of the five named seekers.'});
  let state=rooms.get(room);
  if(!state){state={players:{},key:{x:(Math.random()-.5)*110,z:(Math.random()-.5)*110},winner:null};rooms.set(room,state);}
  if(state.players[name] && state.players[name].socketId!==socket.id) return reply({error:name+' is already in this room.'});
  if(Object.keys(state.players).length>=5 && !state.players[name]) return reply({error:'This room is full (5 players maximum).'});
  socket.join(room); state.players[name]={name,socketId:socket.id,x:0,z:10,progress:0};
  socket.data.room=room; socket.data.name=name;
  reply({room,players:Object.values(state.players).map(({socketId,...p})=>p),keyHint:'Follow the turquoise glow'});
  io.to(room).emit('state', {players:Object.values(state.players).map(({socketId,...p})=>p),winner:state.winner});
 });
 socket.on('move', ({x,z,progress}) => {
  const s=rooms.get(socket.data.room); if(!s||!s.players[socket.data.name])return;
  const p=s.players[socket.data.name];p.x=Math.max(-100,Math.min(100,Number(x)||0));p.z=Math.max(-100,Math.min(100,Number(z)||0));p.progress=Math.max(0,Math.min(100,Number(progress)||0));
  io.to(socket.data.room).emit('state',{players:Object.values(s.players).map(({socketId,...p})=>p),winner:s.winner});
 });
 socket.on('dig',(_,reply=()=>{})=>{
  const room=socket.data.room,s=rooms.get(room),name=socket.data.name;if(!s||!s.players[name])return;
  const p=s.players[name],d=Math.hypot(p.x-s.key.x,p.z-s.key.z);
  if(d<8&&!s.winner){s.winner=name;io.to(room).emit('winner',{name});}
  reply({found:d<8,distanceBand:d<8?'near':d<24?'warm':'cold'});
 });
 socket.on('disconnect',()=>{const s=rooms.get(socket.data.room);if(s&&s.players[socket.data.name]?.socketId===socket.id){delete s.players[socket.data.name];io.to(socket.data.room).emit('state',{players:Object.values(s.players).map(({socketId,...p})=>p),winner:s.winner});if(!Object.keys(s.players).length)rooms.delete(socket.data.room);}});
});
const port=process.env.PORT||3000;server.listen(port,()=>console.log('Lost Kingdom listening on '+port));